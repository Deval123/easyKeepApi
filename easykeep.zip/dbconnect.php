
<?php
/*
 define('HOST','localhost');
define('USER', 'root');
define('PASS','');
define('DB','easyKeep');
$con = mysqli_connect(HOST,USER,PASS,DB);
  if (!$con){
	 die("Error in connection" . mysqli_connect_error()) ;
  }

 define('HOST','localhost');
define('USER', 'habitech_sant');
define('PASS','?bi6JRpHLV.W');
define('DB','habitech_easyKeep');
$con = mysqli_connect(HOST,USER,PASS,DB);
  if (!$con){
	 die("Error in connection" . mysqli_connect_error()) ;
  }
*/

define('HOST','localhost');
define('USER', 'habite1012_easy');
define('PASS','TXTgm8jQ9_xY');
define('DB','habite1012_easykeep');
$con = mysqli_connect(HOST,USER,PASS,DB);

if (!$con){
die("Error in connection" . mysqli_connect_error()) ;
}








?>
